
class Properties {
	Properties();

	factory Properties.fromJson(Map<String, dynamic> json) {
		// TODO: implement fromJson
		throw UnimplementedError('Properties.fromJson($json) is not implemented');
	}

	Map<String, dynamic> toJson() {
		// TODO: implement toJson
		throw UnimplementedError();
	}
}